import 'package:test/test.dart';

main() {
  test('My first test', () {
    // Do something
    int x = 2 + 2;

    // Check something
    expect(x, equals(4));
  });
}

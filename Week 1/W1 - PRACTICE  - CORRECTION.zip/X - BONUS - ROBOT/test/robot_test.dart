import 'package:my_first_project/robot.dart';
import 'package:test/test.dart';

main() {
  test('My first test', () {
    Robot robot = Robot(x: 7, y: 3, direction: Direction.north);

    robot.process(Action.parse("RAALAL"));
    // Print the robot
    print("FINAL POSITION = " + robot.toString());

    // Check the final position
    expect(robot.x, equals(9));
    expect(robot.y, equals(4));
    expect(robot.direction, equals(Direction.west));
  });
}

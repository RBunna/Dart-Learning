class Distance {
  final double meters;

  Distance(this.meters);
  Distance.kms(double kms) : this.meters = kms * 1000;
  Distance.meters(double meters) : this.meters = meters;
  Distance.cms(double cms) : this.meters = cms / 100;
}

enum Direction { north, west, east, south }

enum Action {
  advance,
  turnRight,
  turnLeft;

  static List<Action> parse(String text) {
    List<Action> result = [];
    for (int i = 0; i < text.length; i++) {
      String char = text[i];
      switch (char) {
        case 'A':
          result.add(Action.advance);
          break;

        case 'L':
          result.add(Action.turnLeft);
          break;

        case 'R':
          result.add(Action.turnRight);
          break;

        default:
          throw Exception("Unmanaged case : $char");
      }
    }
    ;
    return result;
  }
}

class Robot {
  int x;
  int y;
  Direction direction;

  Robot({this.x = 0, this.y = 0, this.direction = Direction.north});

  void advance() {
    switch (direction) {
      case Direction.north:
        y++;
        break;
      case Direction.west:
        x--;
        break;
      case Direction.east:
        x++;
        break;
      case Direction.south:
        y--;
        break;
    }
  }

  void turnRight() {
    switch (direction) {
      case Direction.north:
        direction = Direction.east;
        break;
      case Direction.west:
        direction = Direction.north;
        break;
      case Direction.east:
        direction = Direction.south;
        break;
      case Direction.south:
        direction = Direction.west;
        break;
    }
  }

  void turnLeft() {
    switch (direction) {
      case Direction.north:
        direction = Direction.west;
        break;
      case Direction.west:
        direction = Direction.south;
        break;
      case Direction.east:
        direction = Direction.north;
        break;
      case Direction.south:
        direction = Direction.east;
        break;
    }
  }

  void process(List<Action> actions) {
    for (Action action in actions) {
      switch (action) {
        case Action.advance:
          advance();
          break;

        case Action.turnRight:
          turnRight();
          break;

        case Action.turnLeft:
          turnLeft();
          break;
      }
    }
  }

  @override
  String toString() {
    return "x=$x y=$y direction=${direction.name}";
  }
}

main() {
  Robot r = Robot();
  print(r);
}
